/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unl.proyecto.modelo;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author cluster
 */
@Entity
@Table(name = "Estudiante")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Estudiante.findAll", query = "SELECT e FROM Estudiante e"),
    @NamedQuery(name = "Estudiante.findByCedula", query = "SELECT e FROM Estudiante e WHERE e.cedula = :cedula"),
    @NamedQuery(name = "Estudiante.findByNombres", query = "SELECT e FROM Estudiante e WHERE e.nombres = :nombres"),
    @NamedQuery(name = "Estudiante.findByApellidos", query = "SELECT e FROM Estudiante e WHERE e.apellidos = :apellidos"),
    @NamedQuery(name = "Estudiante.findByProgramacion", query = "SELECT e FROM Estudiante e WHERE e.programacion = :programacion"),
    @NamedQuery(name = "Estudiante.findByEnsamblador", query = "SELECT e FROM Estudiante e WHERE e.ensamblador = :ensamblador"),
    @NamedQuery(name = "Estudiante.findByEtica", query = "SELECT e FROM Estudiante e WHERE e.etica = :etica"),
    @NamedQuery(name = "Estudiante.findByEstaditica", query = "SELECT e FROM Estudiante e WHERE e.estaditica = :estaditica"),
    @NamedQuery(name = "Estudiante.findByContabilidad", query = "SELECT e FROM Estudiante e WHERE e.contabilidad = :contabilidad")})
public class Estudiante implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "cedula")
    private Integer cedula;
    @Size(max = 45)
    @Column(name = "Nombres")
    private String nombres;
    @Size(max = 45)
    @Column(name = "Apellidos")
    private String apellidos;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "Programacion")
    private Double programacion;
    @Column(name = "Ensamblador")
    private Double ensamblador;
    @Column(name = "Etica")
    private Double etica;
    @Column(name = "Estaditica")
    private Double estaditica;
    @Size(max = 45)
    @Column(name = "Contabilidad")
    private String contabilidad;

    public Estudiante() {
    }

    public Estudiante(Integer cedula) {
        this.cedula = cedula;
    }

    public Integer getCedula() {
        return cedula;
    }

    public void setCedula(Integer cedula) {
        this.cedula = cedula;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Double getProgramacion() {
        return programacion;
    }

    public void setProgramacion(Double programacion) {
        this.programacion = programacion;
    }

    public Double getEnsamblador() {
        return ensamblador;
    }

    public void setEnsamblador(Double ensamblador) {
        this.ensamblador = ensamblador;
    }

    public Double getEtica() {
        return etica;
    }

    public void setEtica(Double etica) {
        this.etica = etica;
    }

    public Double getEstaditica() {
        return estaditica;
    }

    public void setEstaditica(Double estaditica) {
        this.estaditica = estaditica;
    }

    public String getContabilidad() {
        return contabilidad;
    }

    public void setContabilidad(String contabilidad) {
        this.contabilidad = contabilidad;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (cedula != null ? cedula.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Estudiante)) {
            return false;
        }
        Estudiante other = (Estudiante) object;
        if ((this.cedula == null && other.cedula != null) || (this.cedula != null && !this.cedula.equals(other.cedula))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.unl.proyecto.modelo.Estudiante[ cedula=" + cedula + " ]";
    }
    
}
