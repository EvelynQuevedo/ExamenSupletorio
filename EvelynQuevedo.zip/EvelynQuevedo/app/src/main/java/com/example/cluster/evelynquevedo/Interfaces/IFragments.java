package com.example.cluster.evelynquevedo.Interfaces;

import com.example.cluster.evelynquevedo.Fragmentos.listar_estudiantes;

public interface IFragments extends listar_estudiantes.OnFragmentInteractionListener {
}
