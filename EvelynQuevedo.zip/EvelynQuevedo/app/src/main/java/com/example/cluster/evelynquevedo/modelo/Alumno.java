package com.example.cluster.evelynquevedo.modelo;


public class Alumno {

    private int cedula;
    private String nombre;
    private String apellido;
    private Double programacion;
    private Double emsamblador;
    private Double etica;
    private Double estadistica;
    private String contabilidad;

    public Alumno(){

    }

    public Alumno(int cedula, String nombre, String apellido, Double programacion, Double emsamblador, Double etica, Double estadistica, String contabilidad) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.programacion = programacion;
        this.emsamblador = emsamblador;
        this.etica = etica;
        this.estadistica = estadistica;
        this.contabilidad = contabilidad;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Double getProgramacion() {
        return programacion;
    }

    public void setProgramacion(Double programacion) {
        this.programacion = programacion;
    }

    public Double getEmsamblador() {
        return emsamblador;
    }

    public void setEmsamblador(Double emsamblador) {
        this.emsamblador = emsamblador;
    }

    public Double getEtica() {
        return etica;
    }

    public void setEtica(Double etica) {
        this.etica = etica;
    }

    public Double getEstadistica() {
        return estadistica;
    }

    public void setEstadistica(Double estadistica) {
        this.estadistica = estadistica;
    }

    public String getContabilidad() {
        return contabilidad;
    }

    public void setContabilidad(String contabilidad) {
        this.contabilidad = contabilidad;
    }
}