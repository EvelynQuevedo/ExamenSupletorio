package com.example.cluster.evelynquevedo.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.cluster.evelynquevedo.R;
import com.example.cluster.evelynquevedo.modelo.Alumno;

import java.util.ArrayList;

public class AlumnoAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Alumno> listaAlumno;

    public AlumnoAdapter(Context context, ArrayList<Alumno> listaAlumno) {
        this.context = context;
        this.listaAlumno = listaAlumno;
    }
    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public ArrayList<Alumno> getListaAlumno() {
        return listaAlumno;
    }

    public void setListaAlumno(ArrayList<Alumno> listaAlumno) {
        this.listaAlumno = listaAlumno;
    }


    @Override
    public int getCount() {
        return listaAlumno.size();
    }

    @Override
    public Object getItem(int position) {
        return listaAlumno.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null)
            convertView = View.inflate(context,R.layout.display_alumno, null);

        TextView IdAlumno=convertView.findViewById(R.id.alumnoID);
        TextView Cedula=convertView.findViewById(R.id.cedula);
        TextView Nombre=convertView.findViewById(R.id.nombres);
        TextView Apellido=convertView.findViewById(R.id.apellidos);
        TextView Programacion=convertView.findViewById(R.id.Programacion);
        TextView Ensamblador=convertView.findViewById(R.id.Ensamblador);
        TextView Etica=convertView.findViewById(R.id.Etica);
        TextView Estadistica=convertView.findViewById(R.id.Estadistica);
        TextView Contabilidad=convertView.findViewById(R.id.Contabilidad);

        Alumno alumno = listaAlumno.get(position);

        IdAlumno.setText(String.valueOf(alumno.getCedula()));
        Nombre.setText(alumno.getNombre());
        Apellido.setText(alumno.getApellido());
        Programacion.setText("Programacion"+ String.valueOf(alumno.getProgramacion()));
        Ensamblador.setText("Ensambador"+String.valueOf(alumno.getEmsamblador()));
        Etica.setText("Etica"+String.valueOf(alumno.getEtica()));
        Estadistica.setText("Estaditica"+String.valueOf(alumno.getEstadistica()));
        Contabilidad.setText("Contabilidad"+String.valueOf(alumno.getContabilidad()));


        return convertView;
    }
}