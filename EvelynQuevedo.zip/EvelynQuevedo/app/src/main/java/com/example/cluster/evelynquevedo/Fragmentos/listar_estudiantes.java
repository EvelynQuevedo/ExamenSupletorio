package com.example.cluster.evelynquevedo.Fragmentos;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.cluster.evelynquevedo.R;
import com.example.cluster.evelynquevedo.adapter.AlumnoAdapter;
import com.example.cluster.evelynquevedo.modelo.Alumno;
import com.example.cluster.evelynquevedo.sevicioWeb.ServicioWeb;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link listar_estudiantes.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link listar_estudiantes#newInstance} factory method to
 * create an instance of this fragment.
 */

public class listar_estudiantes extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private Context globalContext = null;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    String consultarID = "http://10.20.14.5:8080/servicioEx/servicioRest/estudiante/estudianteId?cedula=";
    EditText id;
    Button buscarID;
    ServicioWeb servicio;
    List<Alumno> listaAlumnos;
    ListView listaBUscada;
    AlumnoAdapter alumnoAdapter;

    public listar_estudiantes() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentoBuscarNota.
     */
    // TODO: Rename and change types and number of parameters
    public static listar_estudiantes newInstance(String param1, String param2) {
        listar_estudiantes fragment = new listar_estudiantes();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View vista = inflater.inflate(R.layout.fragment_listar_estudiantes, container, false);

        id = vista.findViewById(R.id.txtID);
        buscarID = vista.findViewById(R.id.LISTAR);
        listaBUscada = vista.findViewById(R.id.lista_alumnos);
        globalContext = this.getActivity();
        buscarID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listaAlumnos = new ArrayList<Alumno>();
                servicio = new ServicioWeb();
                String cadenaLlamada = consultarID + id.getText().toString();
                servicio.execute(cadenaLlamada,"2");
                try {
                    String cadena = servicio.get();
                    Log.e("++++++++++++++++", "alumnos:" + cadena);
                    JSONObject respuestaJson = new JSONObject(cadena);
                    // String resultJson = respuestaJson.getString("estado");
                    //if(resultJson.equals("2")){
                    // JSONArray lista = respuestaJson.getJSONArray("alumnos");
                    //for(int i = 0; i < lista.length(); i++){
                    Alumno alumnoNodo = new Alumno();
                    alumnoNodo.setCedula(Integer.parseInt(respuestaJson.getString("cedula")));
                    alumnoNodo.setNombre(respuestaJson.getString("nombres"));
                    alumnoNodo.setApellido(respuestaJson.getString("apellidos"));
                    alumnoNodo.setProgramacion(respuestaJson.getDouble("programacion"));
                    alumnoNodo.setEmsamblador(respuestaJson.getDouble("ensamblador"));
                    alumnoNodo.setEtica((respuestaJson.getDouble("etica")));
                    alumnoNodo.setEstadistica(respuestaJson.getDouble("estaditica"));
                    alumnoNodo.setContabilidad(respuestaJson.getString("contabilidad"));

                    listaAlumnos.add(alumnoNodo);
                    Log.e("++++++++++++++++", "alumnos:" + listaAlumnos.size());

                    alumnoAdapter = new AlumnoAdapter(globalContext , (ArrayList<Alumno>) listaAlumnos);
                    listaBUscada.setAdapter(alumnoAdapter);
                    alumnoAdapter.notifyDataSetChanged();

                    id.setText("");

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();


                }

            }
        });

        return vista;

    }

    //Log.e("****************", "alumnos:" + servicio.cadenaDevolver);



    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}